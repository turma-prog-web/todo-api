create function getallfoo() returns SETOF foo
    language plpgsql
as
$$
DECLARE
    r foo%rowtype;
BEGIN
    FOR r IN SELECT * FROM foo
    WHERE fooid > 0
    LOOP
        -- can do some processing here
        RETURN NEXT r; -- return current row of SELECT
    END LOOP;
    RETURN;
END
$$;

alter function getallfoo() owner to postgres;

